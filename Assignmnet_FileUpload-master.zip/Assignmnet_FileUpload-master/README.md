# Assignmnet_FileUpload
An example of how to upload images locally with Node.js and Multer.


## Usage

### Installation

Install the dependencies

```sh
$ npm install
```

## Install multer
$ npm install save multer

### Serve
To serve in the browser

```sh
$ npm start
```

## install sql
$ npm install -save mysql

and for seeing whether the mysql is install or not.
$sudo mysql -u root -p





# Assignmnet_FileUpload
# file-image-upload-using-express-and-multer-sarbajeetchhetri
# file-image-upload-using-express-and-multer-sarbajeetchhetri
